package Vuelos.view;

import Vuelos.controller.VueloController;
import Vuelos.model.entity.Vuelo;
import Vuelos.model.repository.vueloDaoImpl;
import java.util.List;
import javax.swing.JOptionPane;

public class VuelosABM extends javax.swing.JFrame {

    private final VueloController controladora;
    private vueloDaoImpl vueloDaoImpl;

    public VuelosABM(VueloController vueloController, vueloDaoImpl vueloDaoImpl) {
        initComponents();
        this.controladora = vueloController;
        this.vueloDaoImpl = vueloDaoImpl;
        mostrarVuelos();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNombreAerolinea = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableVuelos = new javax.swing.JTable();
        btnAgregarVuelo = new javax.swing.JButton();
        btnModificarVuelo = new javax.swing.JButton();
        btnBorrarVuelo = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblNombreAerolinea.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNombreAerolinea.setText("NOMBRE AEROLINEA ");

        tableVuelos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nro Vuelo", "Aeropuerto Salida", "Aeropuerto Llegada", "Hora Salida", "Hora Llegada", "Fecha Salida", "Fecha Llegada"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true, true, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tableVuelos);
        if (tableVuelos.getColumnModel().getColumnCount() > 0) {
            tableVuelos.getColumnModel().getColumn(0).setResizable(false);
            tableVuelos.getColumnModel().getColumn(1).setResizable(false);
            tableVuelos.getColumnModel().getColumn(2).setResizable(false);
            tableVuelos.getColumnModel().getColumn(3).setResizable(false);
            tableVuelos.getColumnModel().getColumn(6).setResizable(false);
        }

        btnAgregarVuelo.setText("Añadir");
        btnAgregarVuelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarVueloActionPerformed(evt);
            }
        });

        btnModificarVuelo.setText("Modificar");
        btnModificarVuelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarVueloActionPerformed(evt);
            }
        });

        btnBorrarVuelo.setText("Borrar");
        btnBorrarVuelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarVueloActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1438, Short.MAX_VALUE)
                    .addComponent(lblNombreAerolinea, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(btnAgregarVuelo)
                        .addGap(18, 18, 18)
                        .addComponent(btnModificarVuelo)
                        .addGap(18, 18, 18)
                        .addComponent(btnBorrarVuelo)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblNombreAerolinea)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 518, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBorrarVuelo)
                    .addComponent(btnModificarVuelo)
                    .addComponent(btnAgregarVuelo))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarVueloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarVueloActionPerformed
        VueloController vueloController = new VueloController();
        VuelosAñadir ventanaAñadir = new VuelosAñadir(vueloController, this);
        ventanaAñadir.setVisible(true);
    }//GEN-LAST:event_btnAgregarVueloActionPerformed

    private void btnBorrarVueloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarVueloActionPerformed
        int[] filasSeleccionadas = tableVuelos.getSelectedRows();
        if (filasSeleccionadas.length == 0) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un vuelo.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (filasSeleccionadas.length > 1) {
            JOptionPane.showMessageDialog(this, "Solo puede seleccionar un vuelo.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int filaSeleccionada = tableVuelos.getSelectedRow();

        if (filaSeleccionada != -1) { // Verifica que haya una fila seleccionada
            javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) tableVuelos.getModel();

            int idVuelo = (int) model.getValueAt(filaSeleccionada, 0);
            controladora.removeVuelo(idVuelo);

            // Eliminar la fila de la tabla
            model.removeRow(filaSeleccionada);

        }
        mostrarVuelos();
    }//GEN-LAST:event_btnBorrarVueloActionPerformed

    private void btnModificarVueloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarVueloActionPerformed
        int[] filasSeleccionadas = tableVuelos.getSelectedRows(); // Verifica las filas seleccionadas

        if (filasSeleccionadas.length == 0) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un vuelo.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (filasSeleccionadas.length > 1) {
            JOptionPane.showMessageDialog(this, "Solo puede seleccionar un vuelo.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int filaSeleccionada = tableVuelos.getSelectedRow();
        Vuelo vueloExistente = null;

        if (filaSeleccionada != -1) { // Verifica que haya una fila seleccionada
            javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) tableVuelos.getModel();

            int idVuelo = (int) model.getValueAt(filaSeleccionada, 0);
            vueloExistente = vueloDaoImpl.searchVuelo(idVuelo);
        }

        VueloModificar vueloModificar = new VueloModificar(controladora, this, vueloExistente);
        vueloModificar.setVisible(true);
    }//GEN-LAST:event_btnModificarVueloActionPerformed

    public void mostrarVuelos() {
        List<Vuelo> vuelos = controladora.listVuelos();
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) tableVuelos.getModel();

        model.setRowCount(0);//borra las filas

        // Recorrer la lista de vuelos y agregarlos al modelo de la tabla
        for (Vuelo vuelo : vuelos) {
            model.addRow(new Object[]{
                vuelo.getIdVuelo(),
                vuelo.getNroVuelo(),
                vuelo.getAeropuertoSalida(),
                vuelo.getAeropuertoLlegada(),
                vuelo.getHoraSalida().toString(),
                vuelo.getHoraLlegada().toString(),
                vuelo.getFechaSalida().toString(),
                vuelo.getFechaLlegada().toString()
            });

            tableVuelos.getColumnModel().getColumn(0).setMinWidth(0);
            tableVuelos.getColumnModel().getColumn(0).setMaxWidth(0);
            tableVuelos.getColumnModel().getColumn(0).setWidth(0);
        }
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                VueloController vueloController = new VueloController();
                vueloDaoImpl vueloDaoImpl = new vueloDaoImpl();
                new VuelosABM(vueloController, vueloDaoImpl).setVisible(true);
            }
        });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarVuelo;
    private javax.swing.JButton btnBorrarVuelo;
    private javax.swing.JButton btnModificarVuelo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblNombreAerolinea;
    private javax.swing.JTable tableVuelos;
    // End of variables declaration//GEN-END:variables
}

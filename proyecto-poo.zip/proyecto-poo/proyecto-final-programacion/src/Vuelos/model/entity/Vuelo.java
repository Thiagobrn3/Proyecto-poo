package Vuelos.model.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "vuelos")
public class Vuelo implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idVuelo; // Clave primaria
    
    @Column(name = "numero_vuelo", nullable = false)
    private String nroVuelo;

    @Column(name = "hora_salida", nullable = false)
    private LocalTime horaSalida; // Hora de salida

    @Column(name = "hora_llegada", nullable = false)
    private LocalTime horaLlegada; // Hora de llegada

    @Column(name = "fecha_salida", nullable = false)
    private LocalDate fechaSalida; // Fecha de salida

    @Column(name = "fecha_llegada", nullable = false)
    private LocalDate fechaLlegada; // Fecha de llegada

    @Column(name = "aeropuerto_salida", nullable = false)
    private String aeropuertoSalida; // Aeropuerto de salida

    @Column(name = "aeropuerto_llegada", nullable = false)
    private String aeropuertoLlegada; // Aeropuerto de llegada

    public Vuelo() {
    }

    public Vuelo(String nroVuelo, LocalTime horaSalida, LocalTime horaLlegada, LocalDate fechaSalida, LocalDate fechaLlegada, String aeropuertoSalida, String aeropuertoLlegada) {
        this.nroVuelo = nroVuelo;
        this.horaSalida = horaSalida;
        this.horaLlegada = horaLlegada;
        this.fechaSalida = fechaSalida;
        this.fechaLlegada = fechaLlegada;
        this.aeropuertoSalida = aeropuertoSalida;
        this.aeropuertoLlegada = aeropuertoLlegada;
    }

    // Getters y Setters
    public int getIdVuelo() {
        return idVuelo;
    }

    public String getNroVuelo() {
        return nroVuelo;
    }

    public void setNroVuelo(String nroVuelo) {
        this.nroVuelo = nroVuelo;
    }

    public void setIdVuelo(int idVuelo) {
        this.idVuelo = idVuelo;
    }

    public LocalTime getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(LocalTime horaSalida) {
        this.horaSalida = horaSalida;
    }

    public LocalTime getHoraLlegada() {
        return horaLlegada;
    }

    public void setHoraLlegada(LocalTime horaLlegada) {
        this.horaLlegada = horaLlegada;
    }

    public LocalDate getFechaSalida() {
        return fechaSalida;
    }

    public void setFechaSalida(LocalDate fechaSalida) {
        this.fechaSalida = fechaSalida;
    }

    public LocalDate getFechaLlegada() {
        return fechaLlegada;
    }

    public void setFechaLlegada(LocalDate fechaLlegada) {
        this.fechaLlegada = fechaLlegada;
    }

    public String getAeropuertoSalida() {
        return aeropuertoSalida;
    }

    public void setAeropuertoSalida(String aeropuertoSalida) {
        this.aeropuertoSalida = aeropuertoSalida;
    }

    public String getAeropuertoLlegada() {
        return aeropuertoLlegada;
    }

    public void setAeropuertoLlegada(String aeropuertoLlegada) {
        this.aeropuertoLlegada = aeropuertoLlegada;
    }

    @Override
    public String toString() {
        return "Vuelo{" + "idVuelo=" + idVuelo + ", nroVuelo=" + nroVuelo + ", horaSalida=" + horaSalida + ", horaLlegada=" + horaLlegada + ", fechaSalida=" + fechaSalida + ", fechaLlegada=" + fechaLlegada + ", aeropuertoSalida=" + aeropuertoSalida + ", aeropuertoLlegada=" + aeropuertoLlegada + '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Vuelo other = (Vuelo) obj;
        if (this.idVuelo != other.idVuelo) {
            return false;
        }
        if (!Objects.equals(this.nroVuelo, other.nroVuelo)) {
            return false;
        }
        if (!Objects.equals(this.aeropuertoSalida, other.aeropuertoSalida)) {
            return false;
        }
        if (!Objects.equals(this.aeropuertoLlegada, other.aeropuertoLlegada)) {
            return false;
        }
        if (!Objects.equals(this.horaSalida, other.horaSalida)) {
            return false;
        }
        if (!Objects.equals(this.horaLlegada, other.horaLlegada)) {
            return false;
        }
        if (!Objects.equals(this.fechaSalida, other.fechaSalida)) {
            return false;
        }
        return Objects.equals(this.fechaLlegada, other.fechaLlegada);
    }

    
}

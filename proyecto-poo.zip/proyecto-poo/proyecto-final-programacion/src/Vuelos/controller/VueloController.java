package Vuelos.controller;

import Vuelos.model.entity.Vuelo;
import Vuelos.model.repository.vueloDaoImpl;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class VueloController {

    private vueloDaoImpl vueloDaoImpl;

    public VueloController(vueloDaoImpl vueloDaoImpl) {
        this.vueloDaoImpl = vueloDaoImpl;
    }

    public VueloController() {
        this.vueloDaoImpl = new vueloDaoImpl();  // Asegura que no sea null
    }

    public void addVuelo(String nroVuelo, String aeroSalida, String aeroLlegada, LocalTime horaSalida, LocalTime horaLlegada, LocalDate fechaSalida, LocalDate fechaLlegada) {
        Vuelo nuevoVuelo = new Vuelo(nroVuelo, horaSalida, horaLlegada, fechaSalida, fechaLlegada, aeroSalida, aeroLlegada);
        vueloDaoImpl.createVuelo(nuevoVuelo);
    }

    public void removeVuelo(int idVuelo) {
        vueloDaoImpl.deleteVuelo(idVuelo);
    }

    public void updateVuelo(int idVuelo,LocalTime horaSalida, LocalTime horaLlegada, LocalDate fechaSalida, LocalDate fechaLlegada) {
        Vuelo vueloExistente = vueloDaoImpl.searchVuelo(idVuelo);
        vueloExistente.setHoraSalida(horaSalida);
        vueloExistente.setHoraLlegada(horaLlegada);
        vueloExistente.setFechaSalida(fechaSalida);
        vueloExistente.setFechaLlegada(fechaLlegada);
        vueloDaoImpl.updateVuelo(vueloExistente, idVuelo);
    }

    public List<Vuelo> listVuelos() {
        List<Vuelo> listaVuelos = vueloDaoImpl.readAll();
        return listaVuelos;
    }
}

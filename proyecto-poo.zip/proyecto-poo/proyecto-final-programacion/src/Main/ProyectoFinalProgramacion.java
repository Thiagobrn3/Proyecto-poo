package Main;

import Vuelos.controller.VueloController;
import Vuelos.model.repository.vueloDaoImpl;
import Vuelos.view.VuelosABM;

public class ProyectoFinalProgramacion {

    public static void main(String[] args) {
        VueloController controller = new VueloController();
        vueloDaoImpl vueloDaoImpl = new vueloDaoImpl();
        VuelosABM vuelosAbm = new VuelosABM(controller, vueloDaoImpl);
        vuelosAbm.setVisible(true);
    }
    
}
